# AD-fbi

![test](https://code.harvard.edu/CS107/team06/actions/workflows/test.yml/badge.svg?event=push)
![coverage](https://code.harvard.edu/CS107/team06/actions/workflows/coverage.yml/badge.svg?event=push)

A package computes gradients and performs optimization using the technique of automatic differentiation.